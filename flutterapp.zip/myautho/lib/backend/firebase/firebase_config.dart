import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyA6WTLrswBtjVhEh3DcZWGFUq0QVZB15XY",
            authDomain: "myautho-7390ij.firebaseapp.com",
            projectId: "myautho-7390ij",
            storageBucket: "myautho-7390ij.firebasestorage.app",
            messagingSenderId: "81001399207",
            appId: "1:81001399207:web:8f0a7340946c89ac656c82"));
  } else {
    await Firebase.initializeApp();
  }
}
