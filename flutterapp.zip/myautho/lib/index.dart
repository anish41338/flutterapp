// Export pages
export '/loginpage/loginpage_widget.dart' show LoginpageWidget;
export '/loggedin/loggedin_widget.dart' show LoggedinWidget;
export '/terms/terms_widget.dart' show TermsWidget;
export '/signin/signin_widget.dart' show SigninWidget;
export '/settings/settings_widget.dart' show SettingsWidget;
export '/profile/profile_widget.dart' show ProfileWidget;
export '/chatgpt/chat_ai_screen/chat_ai_screen_widget.dart'
    show ChatAiScreenWidget;
export '/video/video_widget.dart' show VideoWidget;
export '/quotes/quotes_widget.dart' show QuotesWidget;
export '/laws/laws_widget.dart' show LawsWidget;
export '/products/products_widget.dart' show ProductsWidget;
export '/chat/chat_widget.dart' show ChatWidget;
export '/intro/intro_widget.dart' show IntroWidget;
export '/samplepage/samplepage_widget.dart' show SamplepageWidget;
