import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'profile_widget.dart' show ProfileWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ProfileModel extends FlutterFlowModel<ProfileWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for NAME widget.
  FocusNode? nameFocusNode;
  TextEditingController? nameTextController;
  String? Function(BuildContext, String?)? nameTextControllerValidator;
  // State field(s) for ADDRESS widget.
  FocusNode? addressFocusNode;
  TextEditingController? addressTextController;
  String? Function(BuildContext, String?)? addressTextControllerValidator;
  // State field(s) for OCCUPATION widget.
  FocusNode? occupationFocusNode;
  TextEditingController? occupationTextController;
  String? Function(BuildContext, String?)? occupationTextControllerValidator;
  // State field(s) for NUMBER widget.
  FocusNode? numberFocusNode;
  TextEditingController? numberTextController;
  String? Function(BuildContext, String?)? numberTextControllerValidator;
  // State field(s) for CONTACT1 widget.
  FocusNode? contact1FocusNode;
  TextEditingController? contact1TextController;
  String? Function(BuildContext, String?)? contact1TextControllerValidator;
  // State field(s) for CONTACT2 widget.
  FocusNode? contact2FocusNode;
  TextEditingController? contact2TextController;
  String? Function(BuildContext, String?)? contact2TextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    nameFocusNode?.dispose();
    nameTextController?.dispose();

    addressFocusNode?.dispose();
    addressTextController?.dispose();

    occupationFocusNode?.dispose();
    occupationTextController?.dispose();

    numberFocusNode?.dispose();
    numberTextController?.dispose();

    contact1FocusNode?.dispose();
    contact1TextController?.dispose();

    contact2FocusNode?.dispose();
    contact2TextController?.dispose();
  }
}
